<!--php message thing-->
<title>Create New User</title>

<div class="row">
    <div class="col-sm-4">
<!--form input here-->
    </div>
    <div class="col">
        <div class="card-header py-3">
            <p class="text-primary m-0 font-weight-bold">Existing User Details</p>
        </div>
<!--       table here-->
    </div>
</div>
<?php include("../html/footer.php"); ?>
